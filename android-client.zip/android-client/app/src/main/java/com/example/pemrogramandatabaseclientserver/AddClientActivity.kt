package com.example.pemrogramandatabaseclientserver

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class AddClientActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_client)

        val etNama = findViewById<EditText>(R.id.etNama)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)

        btnSimpan.setOnClickListener {

            val nama = etNama.text.toString().trim()
            val email = etEmail.text.toString().trim()

            if (nama.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Nama dan Email wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val url = "http://10.0.2.2/pemrograman_database_client_server/insert_client.php"

            val request = object : StringRequest(
                Method.POST,
                url,
                { response ->
                    Toast.makeText(this, response, Toast.LENGTH_LONG).show()
                    etNama.setText("")
                    etEmail.setText("")
                },
                { error ->
                    Toast.makeText(this, "Volley Error", Toast.LENGTH_LONG).show()
                }
            ) {
                override fun getParams(): MutableMap<String, String> {
                    val params = HashMap<String, String>()
                    params["nama"] = nama
                    params["email"] = email
                    return params
                }
            }

            request.retryPolicy = DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

            Volley.newRequestQueue(this).add(request)
        }
    }
}
